# ip2cord

a python3 libray for converting your internet \
ip address to coordinates

## WARNING
this was made for a [python lesson](https://github.com/TIBTHINK/damien) \
and is not ment for real world useage so if \
the script breaks i will most likely not fix it